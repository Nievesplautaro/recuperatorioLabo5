package com.parcial.NievesPerri;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NievesPerriApplication {

	public static void main(String[] args) {
		SpringApplication.run(NievesPerriApplication.class, args);
	}

}
